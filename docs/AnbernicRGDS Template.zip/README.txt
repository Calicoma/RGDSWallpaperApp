Original PNG is set to be at 300dpi. Ensure your photo editor is set to that setting to confirm the sizes match a real device.



Anbernic RG DS Template  © 2026 by Calicoma is licensed under CC BY-NC-SA 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc-sa/4.0/